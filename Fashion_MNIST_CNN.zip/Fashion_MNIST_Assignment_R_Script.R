# install keras and tensorflow packages
install.packages(c("keras", "tensorflow"))

library(keras)
library(tensorflow)
library(magrittr)

install_keras()
install_tensorflow()

install.packages("magrittr")
install_magrittr()


# Define the model using keras_model_sequential()
model <- keras_model_sequential() %>% 
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = "relu", input_shape = c(28, 28, 1)) %>% 
  layer_max_pooling_2d(pool_size = c(2, 2)) %>% 
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = "relu") %>% 
  layer_max_pooling_2d(pool_size = c(2, 2)) %>% 
  layer_flatten() %>% 
  layer_dense(units = 64, activation = "relu") %>% 
  layer_dense(units = 10, activation = "softmax")

# Compile the model
model %>% compile(
  optimizer = 'adam',
  loss = 'categorical_crossentropy',
  metrics = 'accuracy'
)

# Check the model summary to verify its architecture
summary(model)


# Training the model
history <- model %>% fit(
  train_images, 
  train_labels, 
  epochs = 10, 
  validation_data = list(test_images, test_labels),
  verbose = 2
)

# Predict on two test images
sample_images <- test_images[1:2,,,drop = FALSE]  # Take two images
predictions <- model %>% predict(sample_images)

# Display predictions
for (i in 1:2) {
  plot(as.raster(sample_images[i,,,1], max = 1))  # Plot the image
  predicted_label <- which.max(predictions[i,]) - 1  # Get the predicted label
  cat(sprintf("Prediction for Image %d: %d\n", i, predicted_label))  # Print the result
}



